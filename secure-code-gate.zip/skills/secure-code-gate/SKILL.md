---
name: secure-code-gate
description: Route defensive security reviews by project type and audit codebases, diffs, APIs, web apps, payments, bookings, plugins, bots, mobile and desktop apps, Minecraft mods and server plugins, cloud infrastructure, and AI/MCP systems. Use when asked to find, validate, prioritize, or fix vulnerabilities; perform a release security gate; compare security reviews; or check authentication, authorization, business logic, secrets, dependencies, unsafe inputs, abuse paths, and deployment security.
---

# Secure Code Gate

Run a defensive release gate for the authorized repository or scoped change. Find realistic ways the product can be abused, fail, leak data, cross permission boundaries, or execute untrusted behavior. Produce evidence and safe fixes. Do not provide exploit payloads, intrusion procedures, credential theft, persistence, evasion, or attacks against third-party systems.

## 1. Establish scope and depth

Confirm the repository, branch or commit range, environment, user roles, protected assets, and allowed test actions. Treat production systems, live credentials, customer data, and third-party targets as out of scope unless explicitly authorized.

Choose a depth:

- Focused: review one change plus directly affected trust boundaries.
- Standard: review the changed system, universal families, and every matching project profile.
- High assurance: review the whole reachable security boundary, including configuration, dependencies, deployment, negative tests, and cross-feature abuse. Use this for payments, administrators, sensitive data, public file handling, multi-tenant systems, automatic tools, or privileged plugins.

## 2. Select project profiles

Always read references/security-checklist.md. Select every applicable profile; a project normally matches several.

- Read references/profiles-web-business.md for landing pages, CMS/content sites, authenticated web apps, SaaS, admin panels, payments, stores, marketplaces, booking or fitness systems, user content, file/media handling, realtime features, notifications, analytics, and privacy.
- Read references/profiles-apps-extensions.md for APIs, webhooks, third-party integrations, plugins, browser extensions, bots, CLI tools, local automation, mobile apps, desktop apps, native code, Minecraft mods, Minecraft server plugins, game servers, and connected devices.
- Read references/profiles-platform-ai.md for databases, migrations, backups, cloud, containers, serverless, CI/CD, infrastructure as code, AI, RAG, agents, MCP, and sensitive-domain data.
- Read references/standards-coverage.md when setting audit depth, checking coverage, or claiming readiness.

State the selected profiles and the repository evidence that activated them. Combine profiles. Example: a paid fitness booking site uses authenticated web app, admin, payments, booking, notifications, sensitive-domain data, API, database, and deployment profiles.

## 3. Map threats before findings

Identify:

- Entry points and untrusted data.
- User, staff, administrator, service, plugin, and agent roles.
- Trust and tenant boundaries.
- Privileged state changes and money or entitlement changes.
- Secrets, personal data, files, external requests, and executable content.
- Background jobs, queues, caches, retries, realtime channels, and deployment boundaries.

Trace protected actions end to end. A hidden button or client-side role check is never an authorization control. Verify the server-side decision at the action and object being changed.

## 4. Review in evidence order

1. Read project instructions, architecture, dependency manifests, deployment configuration, schemas, routes, commands, and changed files.
2. Trace untrusted input to sensitive sinks and privileged state changes.
3. Review authorization and business invariants before generic scanners.
4. Run existing deterministic checks: tests, type checks, dependency audit, secret scan, SAST, and relevant project tools.
5. Add safe negative or regression tests for confirmed issues when practical.

Do not install scanners, alter CI, contact live services, or broaden the target without approval. Never call a hypothetical issue confirmed. Mark it Needs confirmation when the code path, precondition, or impact is missing.

## 5. Keep a coverage ledger

Track every applicable universal family and selected profile check as:

- Reviewed — pass.
- Finding.
- Needs confirmation.
- Not tested.
- Not applicable, with reason.

Report checklist coverage as reviewed applicable checks divided by all applicable checks. Do not describe this percentage as the percentage of all possible attacks stopped. Do not declare the gate complete below 70 percent evidence-backed checklist coverage. Target at least 85 percent for Standard and 95 percent for High assurance; list every gap.

## 6. Report findings

For every finding provide:

- Severity: critical, high, medium, low, or informational.
- Affected path, function, endpoint, command, event, or configuration key.
- Violated security invariant.
- Required attacker capability or abuse precondition in defensive terms.
- Evidence and a safe verification method.
- Minimal remediation and possible compatibility impact.
- Regression test or deterministic check.

Separate confirmed findings from hypotheses. Exclude style-only comments unless they create a concrete security consequence. Rank authorization, money, secret exposure, remote execution, tenant crossing, and irreversible data loss above cosmetic hardening.

## 7. Fix and close

Prefer narrow patches. Preserve existing behavior unless the security invariant requires a documented change. Do not weaken authentication, authorization, validation, transport security, auditability, sandboxing, or test assertions merely to pass.

After changes, rerun relevant checks. Summarize:

- Fixed and verified.
- Fixed but not fully verified.
- Rejected reviewer claims and why.
- Remaining risk and untested boundaries.
- Coverage ledger and final release recommendation.

## Independent-review mode

When comparing two reviewer reports or patches:

1. Read the specification, repository, both reports, diffs, and test evidence before accepting conclusions.
2. Validate each claim independently.
3. Merge compatible fixes only after checking their combined behavior.
4. Reject scope expansion, unsafe dependencies, weaker controls, duplicated fixes, and claims without evidence.
5. Run this skill again on the merged result; prior reviewer agreement is not proof.
