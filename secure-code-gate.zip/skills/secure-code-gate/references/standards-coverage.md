# Standards map and coverage rules

Use this file to choose depth and judge completeness. These sources define defensive control families; they do not prove that a particular implementation is secure.

## Contents

1. Baseline sources
2. Profile mapping
3. Audit depth
4. Coverage ledger
5. Release decision

## Baseline sources

- OWASP Application Security Verification Standard 5.0.x: detailed web application verification requirements.
  - https://owasp.org/www-project-application-security-verification-standard/
- OWASP Top 10:2025: broad awareness categories for critical web risks.
  - https://owasp.org/Top10/2025/
- OWASP API Security Top 10:2023: object, function, property, authentication, resource, business-flow, request, inventory, and third-party API risks.
  - https://owasp.org/API-Security/editions/2023/en/0x11-t10/
- OWASP MASVS and MASTG: mobile storage, cryptography, authentication, network, platform, code, resilience, and privacy verification.
  - https://mas.owasp.org/MASVS/
- MITRE CWE Top 25:2025 and On the Cusp: common dangerous implementation weaknesses and nearby high-priority weaknesses.
  - https://cwe.mitre.org/top25/archive/2025/2025_cwe_top25.html
- OWASP Software Component Verification Standard: software supply-chain, SBOM, package, provenance, build, and component controls.
  - https://scvs.owasp.org/
- NIST SP 800-218 SSDF: secure software development lifecycle practices.
  - https://csrc.nist.gov/pubs/sp/800/218/final
- OWASP Top 10 for LLM Applications 2025, LLMSVS, Agentic Applications, and MCP Top 10: AI and tool-using system risks.
  - https://genai.owasp.org/llm-top-10/
  - https://owasp.org/www-project-llm-verification-standard/LLMSVS-v2.0-en.html
  - https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/
  - https://owasp.org/www-project-mcp-top-10/

Prefer the current stable version available in the task environment. If a cited edition is superseded, record the newer edition used.

## Profile mapping

| Project surface | Primary reference families |
|---|---|
| Landing, CMS, web app, SaaS, admin | ASVS, OWASP Top 10, CWE |
| Payments, stores, booking, business workflows | ASVS plus explicit business invariants and provider documentation |
| APIs, webhooks, OAuth | API Security Top 10, ASVS, provider documentation |
| Mobile | MASVS and MASTG plus server-side ASVS or API checks |
| Plugins, extensions, packages, update systems | SCVS, SSDF, CWE, host-platform permission model |
| Desktop, native parsers, Minecraft or game code | CWE, SSDF, supply-chain checks, platform-specific trust and threading rules |
| Cloud, containers, CI/CD, infrastructure | SSDF, SCVS, provider configuration guidance |
| AI, RAG, agents, MCP | OWASP LLM, LLMSVS, Agentic and MCP guidance plus ASVS and API controls |

## Audit depth

### Focused

- Review changed files and directly affected trust boundaries.
- Cover every applicable universal family touched by the change.
- Load every profile directly affected by the change.
- Run existing targeted tests and deterministic checks.
- Do not call the entire product secure.

### Standard

- Review all reachable code for the feature or service.
- Cover every universal family and selected profile.
- Trace every user role through important protected actions.
- Run existing test, dependency, secret, static, and configuration checks.
- Add negative tests for confirmed high and critical issues when practical.
- Target at least 85 percent of applicable checklist items with evidence.

### High assurance

- Review the full reachable security boundary, deployment, dependencies, data stores, asynchronous work, and failure paths.
- Require independent review of administrator, payment, tenant, secret, external execution, and destructive-action boundaries.
- Test role and object denial, replay, concurrency, partial failure, stale state, and resource exhaustion.
- Inspect build and release provenance and production-relevant configuration without contacting production.
- Target at least 95 percent of applicable checklist items with evidence and explicitly block release for uncovered critical boundaries.

## Coverage ledger

Create a table with:

| ID | Check or invariant | Evidence location | Status | Finding |
|---|---|---|---|---|

Allowed statuses:

- Reviewed — pass.
- Finding.
- Needs confirmation.
- Not tested.
- Not applicable — include reason.

Calculate:

- Applicable = all rows except Not applicable.
- Evidence-backed = Reviewed — pass plus Finding rows that include evidence.
- Checklist coverage = Evidence-backed divided by Applicable.

This number measures only the selected checklist. It is not the percentage of attacks prevented, vulnerabilities found, or security guaranteed.

## Release decision

- Pass: no unresolved critical or high finding, required checks pass, and depth target is met.
- Conditional pass: no unresolved critical finding, but bounded medium risk or documented verification gaps remain.
- Fail: confirmed critical or high issue remains, a critical boundary was not tested, required checks fail, or coverage is below 70 percent.
- Unknown: repository, environment, scope, or evidence is too incomplete for a defensible decision.

Never convert Unknown into Pass because two reviewers agree or scanners report zero findings.
