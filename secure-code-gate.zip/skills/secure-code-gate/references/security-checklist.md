# Universal defensive security checklist

Apply this file to every project. Then apply every matching project profile. Test relevant abuse cases safely and locally; do not generate harmful payload collections.

## Contents

1. U01 Scope, assets, and boundaries
2. U02 Authentication and identity
3. U03 Sessions and account lifecycle
4. U04 Authorization and administrative actions
5. U05 Input, injection, and output handling
6. U06 Files, parsers, serialization, and outbound requests
7. U07 Secrets, cryptography, and privacy
8. U08 Business logic, fraud, and abuse
9. U09 State, concurrency, limits, and resilience
10. U10 APIs, callbacks, and integrations
11. U11 Dependencies and software supply chain
12. U12 Build, deployment, and runtime configuration
13. U13 Logging, monitoring, recovery, and deletion
14. U14 Client, native, and local-system boundaries
15. Evidence and severity rules

## U01 Scope, assets, and boundaries

- Inventory public routes, APIs, commands, events, jobs, ports, files, buckets, queues, and administrative interfaces.
- Identify protected assets: accounts, money, entitlements, secrets, personal data, source code, files, compute, and reputation.
- Identify user, moderator, staff, administrator, service, plugin, and machine roles.
- Mark client/server, tenant/tenant, plugin/host, service/service, and internet/internal trust boundaries.
- Find forgotten versions, debug endpoints, test accounts, sample keys, development flags, and undocumented entry points.
- Check default-deny behavior when configuration, identity, or dependency state is missing.

## U02 Authentication and identity

- Enforce authentication on the server for every protected action.
- Verify registration, login, logout, password change, reset, recovery, email or phone verification, and account linking.
- Prevent identity confusion between username, email, external provider subject, tenant, device, and internal ID.
- Apply rate limits and abuse controls to authentication and recovery paths.
- Store passwords only through an established password-hashing implementation with safe parameters.
- Protect MFA enrollment, removal, recovery codes, and fallback methods.
- Prevent account enumeration through response content, timing, logs, and recovery behavior where practical.
- Reauthenticate for credential, payout, ownership, or other high-impact changes.

## U03 Sessions and account lifecycle

- Use unpredictable session tokens and rotate them after authentication or privilege changes.
- Enforce secure cookie or token storage, expiry, revocation, logout, and device/session management.
- Check CSRF protections where browsers attach authority automatically.
- Reject tokens with wrong issuer, audience, tenant, purpose, signature, or time window.
- Invalidate or constrain sessions after password reset, role change, ban, account deletion, or suspected compromise.
- Verify invitation, magic-link, verification, unsubscribe, and recovery tokens are scoped, expiring, and single-purpose.
- Check account merge, rename, deletion, export, suspension, and restoration for ownership and stale access.

## U04 Authorization and administrative actions

- Check function-level authorization on every privileged route, command, job trigger, and event.
- Check object-level authorization on every record, file, message, booking, payment, or resource ID.
- Check field-level authorization so callers cannot set protected properties through mass assignment.
- Enforce ownership and tenant boundaries at the data access layer where practical.
- Validate role changes, invitations, delegation, impersonation, support access, and administrator creation.
- Require authorization again inside background jobs and asynchronous consumers; do not trust the enqueueing client.
- Ensure hidden UI, guessed identifiers, client claims, or cached roles cannot grant authority.
- Log high-impact administrative actions without logging secrets.
- Test denied paths for each meaningful lower-privilege role.

## U05 Input, injection, and output handling

- Validate type, length, range, format, encoding, normalization, and allowed values at each trust boundary.
- Use parameterized database operations; check dynamic table, column, sort, filter, and query fragments separately.
- Pass command arguments without shell interpretation; constrain executable choice and environment.
- Encode untrusted output for HTML, attributes, URLs, JavaScript, CSS, logs, CSV, markdown, and terminal contexts as applicable.
- Sanitize rich text with a maintained allowlist and verify stored content is safe at every later renderer.
- Check template expressions, regular expressions, search syntax, path globs, LDAP or NoSQL filters, and format strings.
- Validate server-side even when schema or UI validation exists on the client.
- Check Unicode normalization, duplicate parameters, ambiguous content types, and parser disagreement at security boundaries.
- Reject unknown fields where accepting them could alter privilege or state.

## U06 Files, parsers, serialization, and outbound requests

- Validate file type from content and required structure, not filename alone.
- Generate storage names server-side; prevent traversal, overwrite, symlink, and cross-tenant access.
- Bound file size, item count, nesting, dimensions, compression ratio, parse time, and generated output.
- Treat archives, images, documents, media metadata, markup, and imported backups as untrusted.
- Avoid unsafe deserialization; use explicit schemas and deny unexpected object types.
- Constrain server-side outbound requests by scheme, destination, redirects, DNS behavior, response size, and timeout.
- Protect internal services, metadata endpoints, localhost, private networks, and privileged Unix or local sockets.
- Serve downloads with safe content type, disposition, authorization, and cache policy.
- Remove sensitive metadata where product requirements call for it.
- Verify deletion covers originals, derivatives, caches, search indexes, and temporary files.

## U07 Secrets, cryptography, and privacy

- Search source, history available to the task, configuration, logs, tests, fixtures, client bundles, crash reports, and artifacts for secrets.
- Use runtime secret management and least-privilege credentials with rotation and revocation paths.
- Never invent cryptography. Use established libraries, authenticated encryption where needed, secure randomness, and documented key lifecycles.
- Protect data in transit and verify certificate and hostname checks are not disabled.
- Minimize personal and sensitive data; document purpose, access, retention, export, correction, and deletion behavior.
- Redact credentials, tokens, payment data, private content, and personal data from logs and errors.
- Check cache keys, CDN behavior, browser storage, clipboard, screenshots, backups, and analytics for accidental disclosure.
- Separate encryption keys from encrypted data and restrict backup access.

## U08 Business logic, fraud, and abuse

- Write invariants for price, balance, entitlement, capacity, ownership, status transitions, quotas, and one-time actions.
- Recompute authoritative values on the server instead of trusting client totals, roles, timestamps, or completion flags.
- Check step skipping, replay, duplicate submission, partial failure, cancellation, refund, retry, and out-of-order events.
- Test abuse across multiple accounts, tenants, referrals, promotions, invitations, trials, and shared resources.
- Prevent negative, zero, overflow, rounding, currency, timezone, and unit mistakes from changing value or permissions.
- Check moderation, approval, dispute, and support workflows for self-approval or conflict of interest.
- Make high-value transitions atomic and auditable.
- Rate-limit by the resource actually being protected, not only by IP address.

## U09 State, concurrency, limits, and resilience

- Check races around balances, inventory, capacity, permissions, filenames, counters, and one-time tokens.
- Use idempotency and deduplication for retried external or money-changing operations.
- Bound request size, batch size, page size, query cost, recursion, fan-out, queue depth, and background work.
- Apply timeouts, cancellation, circuit breaking, and safe retry policies to external calls.
- Prevent user-controlled work amplification, unbounded storage, notification floods, and cost explosions.
- Check cache invalidation and stale authorization after role, ownership, or status changes.
- Fail closed for authorization and integrity; fail safely and recoverably for availability.
- Verify cleanup after disconnect, cancellation, deployment, plugin unload, or crashed jobs.

## U10 APIs, callbacks, and integrations

- Inventory endpoints, versions, hosts, schemas, callbacks, webhook receivers, and deprecated surfaces.
- Authenticate services and validate authorization at object, function, and property levels.
- Constrain OAuth scopes, redirect destinations, state, PKCE, token storage, refresh, revocation, and account binding.
- Verify webhook or callback authenticity using the provider's documented method and original message representation.
- Bind callbacks to the intended tenant, account, operation, amount, environment, and current state.
- Reject replays and process retried callbacks idempotently.
- Validate third-party responses before using them in commands, templates, redirects, database writes, or authorization decisions.
- Protect integration credentials and handle provider failure without silently granting access or losing integrity.

## U11 Dependencies and software supply chain

- Review new direct and transitive dependencies, lockfiles, registries, install scripts, plugins, images, generated code, and binary artifacts.
- Pin or constrain versions appropriately and verify the actual resolved source.
- Run available vulnerability and license checks; distinguish reachable risk from name-only matches.
- Check for dependency confusion, typos, abandoned packages, unexpected maintainers, and unreviewed update channels.
- Restrict build-time network and credentials; prevent untrusted pull requests from accessing deployment secrets.
- Verify provenance or signatures for high-impact binaries, plugins, installers, and updates where supported.
- Produce or inspect an SBOM for high-assurance releases when tooling supports it.
- Remove unused dependencies and privileged capabilities.

## U12 Build, deployment, and runtime configuration

- Separate development, test, staging, and production identities, data, domains, keys, and callbacks.
- Disable debug modes, sample accounts, verbose errors, unsafe consoles, directory listings, and permissive defaults.
- Check CORS, CSP, framing, MIME sniffing, referrer, transport, cookie, and cache headers where applicable.
- Apply least-privilege filesystem, database, cloud, container, process, network, and service permissions.
- Inventory public ports, buckets, dashboards, metrics, health endpoints, admin panels, and management interfaces.
- Protect CI variables, artifacts, caches, logs, runners, deployment approvals, and infrastructure state.
- Pin trusted base images and actions; scan available images and configuration.
- Ensure rollbacks do not restore vulnerable code, incompatible schemas, stale permissions, or revoked secrets.

## U13 Logging, monitoring, recovery, and deletion

- Log authentication, authorization denial, administrative action, money or entitlement change, secret rotation, and security-control failure.
- Include actor, target, time, result, tenant, and correlation ID without sensitive payloads.
- Prevent log injection and protect log access, integrity, retention, and deletion.
- Make alerts actionable for repeated abuse, privilege changes, unusual exports, and integrity failures.
- Verify backups are encrypted, access-controlled, retained appropriately, and restorable.
- Test restore procedures and migration rollback for critical systems.
- Ensure deletion and retention policies cover replicas, backups according to policy, caches, analytics, search, and vendors.
- Keep user-facing errors generic while preserving internal diagnostic evidence safely.

## U14 Client, native, and local-system boundaries

- Treat every client, local file, environment variable, URL handler, IPC message, and localhost request as untrusted.
- Keep authorization and valuable state on the server whenever a server exists.
- Protect local credentials using platform facilities; avoid plaintext configuration and verbose logs.
- Validate deep links, custom protocols, inter-process messages, clipboard content, drag-and-drop, and imported files.
- Check privilege boundaries, sandbox configuration, unsafe native calls, library loading, and updater trust.
- For memory-unsafe code, review bounds, integer conversion, allocation, lifetime, nullability, initialization, format handling, and concurrency.
- Prefer existing fuzzing, sanitizers, and hardening options for parsers and native components when available.
- Require explicit confirmation and a precise target for destructive local actions.

## Evidence and severity rules

- Confirm the reachable code path, violated invariant, required capability, and impact before assigning severity.
- Prefer a regression test, type or static check, configuration assertion, or safe local reproduction.
- Treat remote code execution, administrator takeover, cross-tenant access, money theft, secret compromise, and irreversible mass loss as potentially critical only when demonstrated and reachable.
- Downgrade speculative, defense-in-depth, or environment-dependent claims and state the missing evidence.
- Record code and test coverage gaps. Passing scanners does not prove business-logic or authorization safety.
