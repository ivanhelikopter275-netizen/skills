# Platform, data, infrastructure, AI, and sensitive-domain profiles

Load every matching profile and combine it with the universal checklist.

## Contents

1. P01 Databases, caches, search, migrations, and backups
2. P02 Cloud, containers, serverless, and infrastructure as code
3. P03 CI/CD, source control, artifacts, and release systems
4. P04 AI, LLM, RAG, agents, and MCP
5. P05 Multi-tenant and cross-service platforms
6. P06 Health, fitness, education, minors, finance, identity, and location data
7. P07 High-impact or safety-relevant systems

## P01 Databases, caches, search, migrations, and backups

- Use separate least-privilege identities for application runtime, migration, analytics, backup, and administration.
- Enforce tenant and object isolation consistently across primary database, replicas, cache, search, warehouse, queue, and exports.
- Parameterize data access and constrain dynamic identifiers, filters, sorting, full-text syntax, and administrative queries.
- Protect row-level or document-level security from bypass by service roles, background jobs, direct storage URLs, and maintenance tools.
- Check schema defaults, nullability, uniqueness, foreign keys, checks, state constraints, and ownership fields for security invariants.
- Make money, entitlement, capacity, one-time token, and ownership transitions transactional.
- Review migrations for destructive changes, permission changes, backfills, data exposure, partial execution, rollback, and mixed-version compatibility.
- Ensure caches include tenant and authorization context in keys; invalidate them after permission or visibility changes.
- Keep hidden or deleted data out of search indexes, analytics, autocomplete, and replicas according to policy.
- Encrypt and restrict backups, snapshots, dumps, transaction logs, exports, and local developer copies.
- Test restore, point-in-time recovery, key availability, and permission restoration.
- Ensure retention and deletion rules account for replicas, caches, indexes, backups, and vendor systems.
- Avoid sensitive values in database errors, slow-query logs, traces, and monitoring labels.

## P02 Cloud, containers, serverless, and infrastructure as code

- Inventory accounts, projects, regions, identities, roles, policies, networks, services, endpoints, buckets, queues, keys, and secrets.
- Apply least privilege and separate human, workload, build, deployment, and break-glass identities.
- Check trust policies, role assumption, service accounts, workload identity, OIDC claims, and cross-account access.
- Keep storage, databases, dashboards, registries, management APIs, and metadata services private unless explicitly public.
- Restrict network ingress and egress by actual service need; protect internal and metadata endpoints from application request features.
- Encrypt sensitive data and define key ownership, access, rotation, recovery, and deletion.
- Protect infrastructure state, plan output, logs, snapshots, and generated templates from secrets.
- Pin images and modules appropriately; review provenance, vulnerability results, and update policy.
- Run containers with minimum capabilities, non-root where feasible, read-only or constrained filesystems, resource limits, and isolated secrets.
- Protect orchestration dashboards, admission controls, service accounts, host mounts, privileged mode, and container sockets.
- Validate serverless event source, tenant, schema, retry, deduplication, timeout, concurrency, dead-letter, and secret access.
- Separate environments and prevent production credentials or data from entering previews and tests.
- Review DNS, custom domains, certificates, CDN cache rules, origins, and abandoned resources.
- Ensure monitoring and recovery cover region, dependency, credential, and deployment failure.

## P03 CI/CD, source control, artifacts, and release systems

- Protect protected branches, required reviews, status checks, tag and release permissions, and administrator bypass.
- Prevent untrusted pull requests, forks, issue content, artifacts, caches, or model output from reaching secrets or privileged runners.
- Pin or trust workflow actions, build images, package sources, plugins, and reusable workflows.
- Minimize token scope and lifetime; prefer workload identity to long-lived deployment keys.
- Separate build, test, signing, publishing, and deployment permissions.
- Protect signing keys, notarization, package registry, container registry, release notes, and update metadata.
- Verify artifact provenance, integrity, identity, version, and environment before deployment.
- Prevent cache poisoning, artifact substitution, dependency confusion, and release-name ambiguity.
- Redact secrets from build logs, test output, diffs, coverage, debug bundles, and failure uploads.
- Require approval for production, destructive migration, secret rotation, or broad infrastructure changes according to project policy.
- Make deployments traceable to source, reviewed configuration, dependencies, tests, and actor.
- Define rollback, failed migration, partial rollout, revoked release, and compromised credential procedures.
- Keep self-hosted runners isolated and clean between untrusted jobs.

## P04 AI, LLM, RAG, agents, and MCP

- Treat system prompts, user prompts, retrieved documents, web pages, emails, tool output, files, memory, model output, and other agents as untrusted data.
- Separate instructions from data structurally where possible; do not assume prompt wording creates a security boundary.
- Enforce tool authorization outside the model using user, tenant, action, object, environment, and current policy.
- Give each tool and agent minimum scopes, credentials, network access, filesystem access, and lifetime.
- Require deterministic validation and human approval for destructive, financial, external-message, credential, deployment, or privilege-changing actions.
- Never execute model output directly as shell, SQL, code, template, browser action, infrastructure change, or tool arguments without constraints.
- Validate tool identity, schema, origin, version, and permissions; protect against tool description or result poisoning.
- Bind MCP servers and tools to an allowlist where appropriate; detect shadow or unexpected servers and scope creep.
- Protect tokens and secrets from prompts, context windows, retrieval stores, traces, evaluation data, memory, tool errors, and model-visible files.
- Enforce tenant and document authorization before retrieval and again before output; do not rely on vector similarity as access control.
- Review ingestion sources, chunk metadata, embedding stores, deletion, refresh, poisoning, and citation provenance.
- Bound prompt, context, output, recursion, agent steps, tool calls, retries, parallelism, file size, and monetary spend.
- Prevent one user from causing actions, memory, context, or retrieved data to affect another user or tenant.
- Treat generated links, citations, code, security findings, and claims as untrusted until verified.
- Define behavior for refusal, timeout, hallucination, partial tool failure, conflicting agents, and unavailable models.
- Log tool decisions, approvals, actor, arguments in redacted form, result, and policy decision for high-impact actions.
- For model or agent updates, rerun adversarial and regression evaluations against permissions, data isolation, unsafe output handling, and cost limits.
- For autonomous coding, constrain repository, branch, tools, network, credentials, deployment, and allowed destructive operations.

## P05 Multi-tenant and cross-service platforms

- Maintain one authoritative tenant and actor context across gateway, services, queues, caches, storage, search, analytics, and realtime.
- Do not accept internal trust headers from public callers; establish and authenticate service identity.
- Authorize again in the service that owns the protected resource.
- Propagate only required identity and scope; bind background work to tenant, actor, reason, and originating authorization.
- Prevent confused-deputy behavior where a more privileged service performs an unchecked user-requested action.
- Separate tenant keys, namespaces, quotas, caches, files, indexes, logs, exports, and administrative views.
- Verify cross-service retries and compensating actions cannot repeat money, entitlement, deletion, or notification effects.
- Check stale policy, eventual consistency, partial outage, and service-version skew.
- Restrict internal debug endpoints and management ports; do not treat network location alone as sufficient authorization.
- Test cross-tenant object IDs, shared email addresses, shared external accounts, tenant transfer, invitation, merge, export, restore, and deletion.

## P06 Health, fitness, education, minors, finance, identity, and location data

This is a technical privacy and abuse profile, not legal certification.

- Classify sensitive fields, inferred data, private notes, documents, measurements, diagnoses, performance, attendance, grades, identity, precise location, and financial history.
- Collect the minimum data needed and identify who can see each field and for what purpose.
- Separate ordinary user, guardian, trainer, teacher, clinician, finance, support, administrator, and automated-service access.
- Verify consent, guardian or delegated access, revocation, account transition, and age-related workflows according to product requirements.
- Protect exports, reports, notifications, search, analytics, backups, support tools, and AI features from wider disclosure.
- Prevent indirect disclosure through aggregates, leaderboards, availability, status, error messages, recommendations, and shared devices.
- Require reauthentication and notification for changes to identity, payout, guardian, recovery, or sensitive sharing settings.
- Record access and changes to particularly sensitive data where appropriate.
- Apply strict retention, deletion, correction, and vendor-sharing controls.
- Review emergency, safeguarding, fraud, dispute, and legal-hold paths explicitly; do not let them become silent universal bypasses.
- Document unresolved jurisdictional or policy requirements for specialist review.

## P07 High-impact or safety-relevant systems

Apply when failure can cause substantial financial loss, physical harm, mass data exposure, essential-service disruption, or irreversible automated action.

- Define safety and security invariants, fail-safe states, manual override, separation of duties, and maximum automated authority.
- Require High assurance depth and independent review for critical boundaries.
- Avoid a single model, client, plugin, service, credential, administrator, or external provider being an unchecked point of control.
- Use staged rollout, canarying, rate and value caps, transaction limits, and rapid disable controls.
- Protect configuration and policy changes as code or audited privileged actions.
- Test dependency outage, stale data, clock failure, duplicate events, partial execution, malicious input, and operator error.
- Ensure monitoring detects both availability failure and integrity failure.
- Maintain recovery procedures and verify backups, rollback, and revocation.
- Escalate cryptographic protocol design, smart contracts, safety engineering, regulated compliance, and novel high-impact architecture to a qualified specialist.
- State clearly when repository review cannot establish production security.
