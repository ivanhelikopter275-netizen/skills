# Application, integration, extension, and game profiles

Load every matching profile and combine it with the universal checklist.

## Contents

1. A01 APIs, webhooks, OAuth, and external integrations
2. A02 Plugins, extensions, themes, packages, and host applications
3. A03 Bots, chat integrations, and automation
4. A04 CLI tools, developer tools, and local automation
5. A05 Mobile applications
6. A06 Desktop applications
7. A07 Native libraries, parsers, and memory-unsafe code
8. A08 Minecraft mods, server plugins, proxies, and game servers
9. A09 Game clients, launchers, and update systems
10. A10 Connected devices, IoT, and local-network services

## A01 APIs, webhooks, OAuth, and external integrations

- Inventory every API host, route, method, version, schema, undocumented endpoint, callback, and deprecation state.
- Enforce object-level, function-level, and property-level authorization on every operation.
- Reject mass assignment of ownership, role, price, status, tenant, verification, or internal fields.
- Bound pagination, filtering, batch operations, query complexity, response size, upload size, and expensive actions.
- Prevent excessive data exposure by designing response schemas for each caller and role.
- Authenticate service-to-service requests and rotate scoped credentials.
- Validate content type and schema before business logic; handle duplicate and ambiguous fields consistently.
- Maintain an endpoint and version inventory; remove or protect debug, beta, old, and shadow deployments.
- For OAuth, validate redirect destinations, state, PKCE where applicable, scope, account binding, token audience, refresh, and revocation.
- For webhooks, verify authenticity before parsing into trusted state, bind the event to environment and account, reject replays, and process idempotently.
- Treat third-party data as untrusted input; never feed it directly to a shell, template, redirect, authorization decision, or unsafe parser.
- Define failure, timeout, retry, partial success, provider compromise, and credential revocation behavior.
- Prevent server-side request features from reaching internal or privileged destinations.

## A02 Plugins, extensions, themes, packages, and host applications

Apply this profile to CMS plugins, browser extensions, IDE extensions, game plugins, build plugins, themes with executable hooks, and applications that load third-party modules.

- Define the host/plugin trust boundary, lifecycle, permission model, data ownership, and isolation guarantees.
- Request the minimum manifest, filesystem, network, browser-origin, command, database, and host API permissions.
- Enforce authorization inside plugin entry points; never assume the host UI already checked it.
- Validate messages crossing host/plugin, extension/page, background/content-script, or plugin/plugin boundaries.
- Restrict dynamic code loading, reflection, eval-like behavior, template execution, and untrusted configuration.
- Protect host secrets and user data from plugins that do not need them.
- Isolate plugin storage by instance, tenant, and user; prevent predictable namespace collision.
- Review install, enable, disable, update, downgrade, migration, rollback, and uninstall behavior.
- Verify update source, package identity, provenance or signature where supported, and version compatibility.
- Prevent archive extraction, package import, or theme upload from writing outside the intended directory.
- Bound plugin hooks, event listeners, background work, recursion, and failure so one plugin cannot exhaust or crash the host.
- Clean up tasks, listeners, files, routes, permissions, and secrets on disable or uninstall.
- For browser extensions, constrain externally connectable origins, content-script injection, message senders, tab access, downloads, native messaging, and web-accessible resources.
- For server plugins, ensure plugin commands, APIs, scheduled tasks, and console bridges retain the server's authorization model.
- Review dependency and maintainer risk as part of every plugin update.

## A03 Bots, chat integrations, and automation

- Authenticate provider webhooks, callback queries, interactive actions, slash commands, and event deliveries.
- Resolve the real user, workspace, channel, thread, tenant, and bot installation before authorization.
- Distinguish direct messages, groups, channels, administrators, owners, and anonymous or forwarded content.
- Check permissions for every command and callback; do not trust button visibility or command naming.
- Bind interactive tokens and state to the initiating user, conversation, action, and expiry.
- Protect bot tokens, signing secrets, OAuth credentials, and installation records.
- Prevent replay, duplicate delivery, event loops, self-triggering automation, and cross-workspace data leakage.
- Bound messages, mentions, files, commands, retries, scheduled jobs, and paid API use.
- Treat message text, links, attachments, quoted content, and fetched pages as untrusted.
- Require explicit confirmation for destructive, financial, external-message, or privilege-changing actions.
- If AI is involved, apply the AI and MCP profile and prevent prompt content from silently granting tool authority.
- Keep private content out of public errors, logs, analytics, and unintended channels.

## A04 CLI tools, developer tools, and local automation

- Treat command-line arguments, environment variables, current directory, repository files, config, stdin, and tool output as untrusted.
- Avoid shell interpretation; pass explicit argument arrays and constrain executable selection.
- Resolve paths safely and protect against traversal, symlink replacement, unexpected working directories, and overwrite.
- Create temporary files with restrictive permissions and unpredictable names; clean them safely.
- Require explicit target and confirmation for destructive, recursive, remote, credential, or deployment actions.
- Do not execute repository hooks, config, generated scripts, or model output merely because the project contains them.
- Redact credentials from command output, history, logs, process arguments, crash reports, and copied diagnostics.
- Apply least privilege to filesystem, network, cloud, Git, package manager, and subprocess access.
- Verify plugin, package, compiler, formatter, and updater provenance.
- Handle partial writes and interruption atomically; preserve recoverable backups when modifying important local data.
- Avoid broad globs and unresolved variables for destructive targets.
- Distinguish local preview from production deployment and require appropriate approval.

## A05 Mobile applications

Use current OWASP MASVS categories as a completeness reference.

- Store credentials and sensitive data with platform security facilities; review databases, preferences, caches, logs, clipboard, screenshots, notifications, backups, and shared storage.
- Keep authorization and valuable state server-side; do not trust local role, subscription, clock, device, or biometric results alone.
- Validate deep links, universal or app links, custom URL schemes, intents, exported components, IPC, and share targets.
- Constrain WebViews, JavaScript bridges, navigation, file access, mixed content, and external origins.
- Request minimum permissions and handle denial without unsafe fallback.
- Verify transport security, certificate checks, hostname validation, and network-security exceptions.
- Protect local cryptographic keys, tokens, refresh credentials, and offline queues.
- Authorize push-notification registration and avoid private lock-screen content.
- Validate files and content received from cameras, galleries, document providers, NFC, Bluetooth, QR codes, and other apps.
- Check application switching, background snapshots, task history, pasteboard, and accessibility exposure for sensitive screens.
- Review app signing, release configuration, debug flags, test endpoints, symbol files, and third-party SDKs.
- Treat rooting, jailbreaking, emulation, and integrity signals as risk signals, not sole authorization controls.
- Test offline changes, conflict resolution, logout, account switch, device loss, reinstall, and backup restore.

## A06 Desktop applications

- Verify installers and automatic updates have a trusted source, integrity or signature check, rollback protection where needed, and safe failure.
- Protect local API servers, localhost ports, named pipes, Unix sockets, shared memory, and IPC with authentication and caller validation.
- Validate custom protocols, file associations, deep links, drag-and-drop, clipboard, imported projects, and recent-file lists.
- Constrain embedded browsers, navigation, JavaScript bridges, downloads, file URLs, and remote content.
- Store tokens and keys using platform facilities; restrict config, database, log, crash dump, and backup permissions.
- Prevent unsafe dynamic library, plugin, executable, or resource loading from writable or attacker-controlled locations.
- Run with least privilege; separate elevated helpers and validate every request they accept.
- Protect temporary files, update staging, extraction, symlinks, and destination paths.
- Avoid placing secrets in process arguments, environment dumps, diagnostic bundles, or telemetry.
- Define multi-user-machine separation and protect data from other local accounts where required.
- Check lock-screen, sleep, logout, uninstall, and account-switch behavior.
- Bound local parsing, indexing, previewing, thumbnailing, synchronization, and background tasks.

## A07 Native libraries, parsers, and memory-unsafe code

- Identify all untrusted binary, text, network, archive, media, protocol, and FFI inputs.
- Check length and bounds before allocation, copy, indexing, slicing, pointer arithmetic, and terminator handling.
- Check integer width, sign, truncation, overflow, underflow, multiplication, and size conversion.
- Review ownership, lifetime, use-after-free, double free, uninitialized state, nullability, and cleanup on error.
- Check format strings, variadic calls, unsafe casts, alignment, endianness, and structure packing.
- Validate recursion, nesting, state-machine transitions, parser ambiguity, and partial input behavior.
- Constrain allocation, decompression, CPU, stack, thread, handle, and file-descriptor consumption.
- Review race conditions, atomics, locks, callbacks, reentrancy, and signal or cancellation handling.
- Validate FFI and serialization boundaries on both sides.
- Use existing compiler hardening, warnings, sanitizers, static analysis, and fuzz targets when available.
- Add minimal regression inputs for confirmed parser defects without publishing weaponized samples.

## A08 Minecraft mods, server plugins, proxies, and game servers

Apply to Fabric, Forge, NeoForge, Bukkit, Spigot, Paper, Velocity, BungeeCord, modpacks, and custom game-server code. Adapt API details to the actual platform and version.

- Keep the server authoritative for permissions, inventory, economy, position, damage, cooldowns, crafting, rewards, ranks, and protected world changes.
- Check every command, subcommand, alias, event action, GUI click, plugin message, packet handler, RPC, and administrative API for permission and sender type.
- Do not trust client packets, custom payloads, NBT, item metadata, books, signs, chat, resource-pack responses, coordinates, slot numbers, or claimed state.
- Validate packet and message length, structure, rate, sequence, dimension or world, entity, player, and current game state.
- Protect console, RCON, operator, permission-plugin, proxy, and cross-server trust boundaries.
- Ensure remote console or web administration is not enabled with defaults or exposed unintentionally.
- Prevent inventory, currency, reward, shop, trade, auction, claim, teleport, cooldown, and duplication races with atomic server-side state.
- Check negative, oversized, stale, duplicate, out-of-order, disconnected, dead, spectator, and cross-world actions.
- Bound chunk generation, entity spawning, block scans, pathfinding, world edits, scheduled tasks, database queries, packet fan-out, and per-player storage.
- Avoid blocking network, database, filesystem, or heavy computation on the main server thread.
- Respect platform thread rules; synchronize shared state and do not call unsafe server APIs asynchronously.
- Validate world names, schematic names, config paths, player-supplied filenames, archive imports, and generated output paths.
- Treat configuration, localization, scripts, placeholders, templates, and commands from other plugins as untrusted integration input.
- Scope database rows, caches, metadata, and persistent data to the correct server, world, player UUID, and plugin namespace.
- Protect database, proxy, RCON, webhook, and third-party service credentials.
- Review reflection, mixins, bytecode transformation, native libraries, bundled jars, shaded dependencies, and version-specific internal APIs.
- Verify plugin or mod download source, update mechanism, dependency identity, signatures or checksums where supported, and server compatibility.
- Clean up listeners, tasks, channels, commands, temporary files, locks, and connections on reload or shutdown.
- Test ordinary player, wrong permission, operator, console, command block where relevant, proxy message, disconnected player, and malicious or modified client assumptions.
- For client mods, protect account tokens, multiplayer addresses, chat logs, screenshots, telemetry, local files, and automatic updates.
- Treat anti-cheat as defense in depth; never rely on the client to enforce valuable state.

## A09 Game clients, launchers, and update systems

- Protect account, refresh, session, server, and purchase tokens in storage, logs, crash reports, and process arguments.
- Verify launcher, modpack, asset, native library, and game update origin and integrity.
- Prevent path traversal or overwrite during archive extraction and version installation.
- Isolate versions, profiles, mods, servers, and accounts where the product promises separation.
- Treat multiplayer messages, server resource packs, custom URLs, chat links, and downloaded content as untrusted.
- Constrain embedded web login, redirect handling, custom protocols, and external browser handoff.
- Avoid running downloaded tools or scripts without explicit trust and verification.
- Apply limits to decompression, asset parsing, screenshots, logs, caches, and repeated update attempts.
- Define safe rollback and partial-update recovery.
- Keep telemetry deliberate, minimal, disclosed, and free of credentials or private chat.

## A10 Connected devices, IoT, and local-network services

- Inventory physical, radio, local-network, cloud, mobile-app, debug, update, and recovery interfaces.
- Remove default credentials and establish unique device identity and secure provisioning.
- Authenticate commands and bind them to device, owner, tenant, role, and current state.
- Protect pairing, ownership transfer, factory reset, recovery, and decommissioning.
- Verify firmware and configuration update authenticity, integrity, version policy, and rollback behavior.
- Minimize exposed ports, discovery data, local web interfaces, debug consoles, serial access, and maintenance accounts.
- Protect secrets against extraction appropriate to the threat model; do not share one global secret across all devices.
- Bound messages, storage, logs, radio use, retries, and actuator commands.
- Fail safely when cloud, time, network, sensor, or dependency data is unavailable or untrusted.
- Separate safety-critical actions from convenience automation and require appropriate confirmation.
- Define security support, key rotation, vulnerability update, and end-of-life behavior.
