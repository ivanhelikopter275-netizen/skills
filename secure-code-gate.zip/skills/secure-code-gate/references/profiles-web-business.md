# Web and business project profiles

Load every profile that matches the product. Combine these checks with the universal checklist.

## Contents

1. W01 Landing pages and marketing sites
2. W02 CMS, blogs, and content publishing
3. W03 Authenticated web apps, dashboards, and SaaS
4. W04 Administrators, staff tools, and support consoles
5. W05 Payments, billing, and subscriptions
6. W06 Stores, marketplaces, promotions, and payouts
7. W07 Booking, fitness, appointments, and events
8. W08 Community, chat, comments, and user content
9. W09 File upload, media processing, and downloads
10. W10 Realtime and collaborative features
11. W11 Email, SMS, push, and one-time codes
12. W12 Analytics, tracking, privacy, and consent

## W01 Landing pages and marketing sites

Apply even to a supposedly static site when it contains forms, analytics, previews, third-party scripts, redirects, or deployment automation.

- Inventory contact, newsletter, lead, search, referral, download, and preview endpoints.
- Validate forms server-side; protect email or CRM relays from spam, header manipulation, oversized input, and automated abuse.
- Rate-limit actions that send email, create CRM records, consume paid APIs, or reveal whether an address exists.
- Verify no administration, draft preview, environment file, source map, build artifact, or deployment dashboard is unintentionally public.
- Review redirects and campaign parameters so untrusted destinations or script contexts are not created.
- Minimize third-party scripts, pixels, chat widgets, tag managers, and form processors; document what data each receives.
- Apply browser security headers appropriate to the site and verify framing is intentionally allowed or denied.
- Check secrets and internal endpoints are not embedded in static bundles, source maps, HTML comments, or build logs.
- Ensure download links cannot expose private or unpublished assets.
- Check custom-domain, DNS, and abandoned-subdomain ownership when configuration is present.

## W02 CMS, blogs, and content publishing

- Separate author, editor, publisher, moderator, and administrator capabilities on the server.
- Verify draft, preview, schedule, publish, unpublish, archive, restore, and delete transitions.
- Scope preview and share tokens to content, audience, purpose, and expiry.
- Sanitize rich text, embeds, markdown, SVG, templates, and imported content at the correct rendering boundary.
- Authorize media library reads, replacements, derivatives, metadata edits, and deletion.
- Check comments, mentions, pingbacks, trackbacks, feeds, search, and syndication for injection, spam, data exposure, and amplification.
- Review themes, extensions, plugins, importers, exporters, and update channels as executable supply-chain components.
- Prevent authors from selecting server templates, executable file types, internal URLs, or privileged block types they should not control.
- Preserve author and publication audit history; protect revision restore from bypassing current validation.
- Verify backups and exports do not disclose unpublished content, credentials, private comments, or user data.

## W03 Authenticated web apps, dashboards, and SaaS

- Enforce tenant selection from trusted session context, not request parameters alone.
- Test cross-tenant access for every object type, search, export, attachment, cache, background job, and realtime subscription.
- Authorize invitations, membership, role changes, team transfer, project transfer, API key creation, and organization deletion.
- Verify feature flags and billing entitlements on the server; do not trust hidden UI or client plan labels.
- Review onboarding, trial, suspension, downgrade, cancellation, reactivation, and tenant deletion for stale access.
- Bind API keys and service accounts to tenant, scopes, environment, owner, expiry, rotation, and audit history.
- Protect exports, reports, dashboards, search, and bulk operations from excessive data exposure and resource exhaustion.
- Check saved filters, formulas, templates, automations, and custom fields for injection into later processors.
- Invalidate caches, sessions, invitations, and queued work after role or tenant changes.
- Make account and organization transfer explicit, reauthenticated, notified, and auditable.

## W04 Administrators, staff tools, and support consoles

- Require server-side administrator or precise staff permission for every action, including internal APIs and jobs.
- Prefer granular roles over a single administrator boolean; deny unrecognized roles.
- Require strong authentication and reauthentication for destructive, credential, payout, export, or impersonation actions.
- Protect browser actions from CSRF and clickjacking where applicable.
- Ensure bulk actions authorize every target object and cannot cross tenant or scope boundaries.
- Restrict staff search, exports, logs, user content, secrets, and payment information to job need.
- Make impersonation time-limited, visibly indicated, audited, and unable to silently perform prohibited actions.
- Prevent self-approval of role escalation, payout change, moderation appeal, refund, or other dual-control workflow.
- Verify emergency access, bootstrap administrator creation, default accounts, and recovery procedures.
- Record actor, reason, target, before/after state, and result for high-impact changes.
- Test direct requests as anonymous, ordinary user, suspended user, moderator, support staff, and wrong-tenant administrator.

## W05 Payments, billing, and subscriptions

- Treat the payment provider as authoritative for confirmed payment state; never trust the browser success page.
- Compute product, price, quantity, discount, tax, fee, and currency server-side from trusted records.
- Bind checkout and callbacks to the intended user, tenant, order, amount, currency, environment, and current state.
- Verify webhook authenticity exactly as the provider documents, including use of the original body representation when required.
- Reject callback replay and process retries idempotently; make fulfillment and ledger updates atomic.
- Model explicit states for pending, authorized, captured, failed, expired, canceled, refunded, disputed, and reversed operations.
- Verify subscription activation, renewal, grace, pause, upgrade, downgrade, proration, cancellation, and reactivation.
- Do not grant durable entitlement before the authoritative event; remove or constrain it after refund, chargeback, expiry, or cancellation according to policy.
- Authorize refunds, credits, coupon creation, manual capture, payout changes, and invoice access; audit them.
- Prevent amount, currency, rounding, negative quantity, duplicate fulfillment, and race-condition errors.
- Minimize payment-data scope; never log full payment credentials or sensitive authentication data.
- Verify customer-portal links, invoices, receipts, and payment-method changes belong to the correct account.
- Test provider outage, delayed webhook, duplicate webhook, out-of-order event, client abandonment, and local transaction failure.

## W06 Stores, marketplaces, promotions, and payouts

- Recalculate cart price, availability, shipping, tax, discount, commission, and final total on the server.
- Reserve or decrement inventory atomically and define oversell, cancellation, and restock behavior.
- Enforce promotion eligibility, usage limits, stacking rules, referral ownership, trial rules, and gift balance invariants.
- Prevent users from benefiting from their own referral, review, moderation, purchase, dispute, or approval when disallowed.
- Separate buyer, seller, courier, moderator, finance, and support permissions.
- Protect seller payout destination changes with reauthentication, delay or notification, and audit.
- Bind order status transitions to permitted actors and predecessor states.
- Authorize order details, addresses, messages, invoices, returns, disputes, and downloadable goods.
- Protect search and recommendation feeds from exposing hidden, private, embargoed, or tenant-specific inventory.
- Verify digital delivery links are scoped, expiring where appropriate, and not guessable.
- Bound cart, wishlist, review, message, dispute, and checkout abuse.
- Model refund, partial refund, chargeback, failed payout, split order, and partial shipment consistently.

## W07 Booking, fitness, appointments, and events

Apply this profile to gyms, trainers, classes, clinics, salons, tutors, rentals, tables, tickets, and reservation systems.

- Authorize create, view, reschedule, cancel, check-in, no-show, refund, and attendance actions by object and role.
- Separate customer, trainer, venue staff, manager, administrator, and service capabilities.
- Do not infer authority from the existence of an administrator page or client role; check it at every server action.
- Enforce capacity, resource, location, trainer, membership, age, waiver, cancellation-window, and eligibility rules server-side.
- Make capacity checks and booking creation atomic to prevent double booking or oversubscription.
- Define timezone, daylight-saving, recurrence, exception, buffer, duration, and overnight behavior.
- Protect waitlist position and promotion; make notifications and acceptance links scoped, expiring, and one-use where appropriate.
- Prevent users from reading another person's attendance, private notes, injuries, measurements, plan, or contact details.
- Restrict trainer and staff visibility to assigned classes, locations, or customers.
- Bind paid bookings, credits, memberships, passes, refunds, and cancellation fees to authoritative billing state.
- Verify calendar feeds, ICS links, QR codes, check-in tokens, and public booking IDs do not expose or grant excess access.
- Limit automated slot scanning, reservation hoarding, repeated cancellation, invitation spam, and notification floods.
- Audit manual capacity override, complimentary booking, attendance change, refund, and staff reassignment.
- Test simultaneous last-slot booking, reschedule across capacity, expired membership, staff role removal, and delayed payment event.

## W08 Community, chat, comments, and user content

- Sanitize and context-encode posts, profiles, comments, reactions, markdown, mentions, links, embeds, and previews.
- Enforce visibility for private profiles, rooms, groups, blocked users, deleted content, drafts, and moderation-only data.
- Authorize edit, delete, pin, invite, kick, ban, mute, report resolution, and moderator note access.
- Prevent blocked or banned users from bypassing restrictions through alternate endpoints, mentions, invitations, or realtime channels.
- Treat link preview and media fetchers as outbound-request boundaries; constrain destinations, redirects, size, and content.
- Protect message history, search, exports, notification previews, and quoted content after privacy or deletion changes.
- Bound spam, mass mention, reaction, follow, invitation, report, and attachment abuse.
- Distinguish user deletion, moderator removal, legal hold, tombstones, and audit requirements.
- Avoid exposing private content in logs, moderation tooling, analytics, search indexes, or push notifications.
- Check automated moderation and AI summaries for tenant or room leakage and unsafe action authority.

## W09 File upload, media processing, and downloads

- Allow only required formats and verify decoded structure rather than trusting extension or declared MIME type.
- Generate object names server-side and isolate tenant or user namespaces.
- Authorize upload initiation, multipart completion, read, transform, share, replace, and delete.
- Scope signed upload and download URLs by object, operation, content constraints, and expiry.
- Keep storage buckets private unless every object is intentionally public.
- Bound bytes, dimensions, duration, pages, archive entries, compression, metadata, processing time, and derivative count.
- Run available malware or content scanning where risk and tooling justify it; quarantine until required checks finish.
- Sandbox or isolate risky processors and keep them patched.
- Strip or preserve metadata deliberately; do not leak location, author, local path, or device information unintentionally.
- Serve active formats defensively and prevent uploaded content from inheriting application origin when possible.
- Protect import, archive extraction, thumbnailing, transcoding, OCR, and document conversion against resource amplification.
- Ensure failed and abandoned uploads, temporary files, old versions, caches, and derivatives follow retention and deletion policy.

## W10 Realtime and collaborative features

- Authenticate the initial connection and reauthorize every subscription, room, document, and privileged message.
- Bind topics and channels to tenant and object; never let the client choose an unchecked internal channel name.
- Validate every message schema, size, rate, sequence, and allowed state transition.
- Treat reconnect, replay, duplicate delivery, reordering, and stale version as normal conditions.
- Prevent client-authoritative balances, inventory, positions, permissions, locks, or document ownership.
- Enforce connection, subscription, presence, broadcast, history, and fan-out limits.
- Protect presence, typing, cursor, and online status according to privacy rules.
- Define conflict resolution and reject stale writes that would bypass authorization or overwrite protected state.
- Revoke active subscriptions promptly after role, room, tenant, or account changes.
- Clean up locks, sessions, and resources on disconnect and worker failure.

## W11 Email, SMS, push, and one-time codes

- Verify the destination belongs to the intended account before sending sensitive content or authorization links.
- Prevent untrusted input from changing message headers, sender, reply-to, recipients, template selection, or link destinations.
- Keep secrets, full private content, and unnecessary personal data out of lock-screen and email previews.
- Scope one-time codes and links to identity, purpose, operation, and expiry; make sensitive ones single-use.
- Rate-limit send, verify, resend, invitation, mention, and password-recovery flows by account and destination.
- Prevent account enumeration and notification bombing.
- Authorize template editing, audience selection, bulk sends, and suppression-list changes.
- Protect unsubscribe and preference links from changing another user's settings.
- Validate provider callbacks and avoid trusting delivery status as proof of user control.
- Audit high-impact sends and credential or destination changes.

## W12 Analytics, tracking, privacy, and consent

- Inventory events, identifiers, cookies, SDKs, pixels, recordings, crash reports, and downstream vendors.
- Collect only required fields; avoid secrets, message bodies, health details, payment details, and raw authentication data.
- Enforce consent and preference state before optional collection or sharing when required by product policy or law.
- Prevent user-controlled event names or properties from causing injection, excessive cardinality, or cost amplification.
- Restrict access to raw events, session replay, location, exports, and user-level analytics.
- Define retention, deletion, export, correction, and vendor propagation.
- Avoid placing sensitive values in URLs where logs, history, referrers, or third parties can receive them.
- Separate production analytics from tests and prevent debug collection from leaking real data.
- Verify anonymization or aggregation claims against actual identifiers and joinability.
- Document unresolved legal or compliance questions instead of treating a code review as legal certification.
